<?php
/**
 * 该文件主要是存放业务状态码相关的配置
 * Created by PhpStorm.
 * User: singwa
 * Date: 2019-11-23
 * Time: 14:00
 */

return [
    "token_pre" => 'pipi_',
];
