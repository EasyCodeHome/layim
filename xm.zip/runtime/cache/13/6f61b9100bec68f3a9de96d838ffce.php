<?php
//000000000000
 exit();?>
a:3:{s:2:"id";i:1;s:8:"username";s:4:"yaya";s:6:"avatar";s:45:"http://q1.qlogo.cn/g?b=qq&nk=1003713200&s=100";}